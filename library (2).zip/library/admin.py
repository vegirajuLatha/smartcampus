from django.contrib import admin

# Register your models here.
# admin.py
from .models import Penalty

@admin.register(Penalty)
class PenaltyAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'amount', 'reason', 'issued_on', 'is_paid')
    list_filter = ('is_paid', 'issued_on')
